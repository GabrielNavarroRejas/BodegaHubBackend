package com.bodegahub.sistema_bodega;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaBodegaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaBodegaApplication.class, args);
	}

}
