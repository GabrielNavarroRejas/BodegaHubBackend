package com.bodegahub.sistema_bodega;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaBodegaApplicationTests {

	@Test
	void contextLoads() {
	}

}
